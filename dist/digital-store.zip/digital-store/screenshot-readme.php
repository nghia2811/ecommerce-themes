<?php
/**
 * Theme screenshot placeholder.
 * Replace this file with a 1200×900px screenshot.png of your design.
 */
